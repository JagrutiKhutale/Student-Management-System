import java.sql.*;

public class Dbconn {
    
    public static Connection connection() throws Exception
    {
    
         Connection con;
         
                 
           Class.forName("com.mysql.jdbc.Driver");
         con=DriverManager.getConnection("jdbc:mysql://localhost:3306/stud", "root", "admin");
        
       return(con);
    }
    }