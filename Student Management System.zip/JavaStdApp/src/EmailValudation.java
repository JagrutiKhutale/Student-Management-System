
import java.util.regex.Pattern;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Shreya
 */
import java.util.regex.*;
public class EmailValudation {
    public static boolean ValidateEmail(String em)
    {
        String emRegex="[a-zA-Z0-9_+&*-]+(?:\\."+"[a-zA-Z0-9_+&*-]+)*@"+"(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern=Pattern.compile(emRegex);
        if (em==null)
        {
            return false;
        }
    
        return pattern.matcher(em).matches();
    }

}
      /*  if(pattern.matcher(em).matches())
        {
            return "It valid";
        }
        return "it not valid";
    }
    public static void main(String args[])
    {
        EmailValudation ev=new EmailValudation();
        String email1="nik@gmail.com";
        String email2="nik";
        System.out.println("Email1"+email1+" "+ev.ValidateEmail(email1));
        System.out.println("Email2"+email2+" "+ev.ValidateEmail(email2));

    }
}
*/